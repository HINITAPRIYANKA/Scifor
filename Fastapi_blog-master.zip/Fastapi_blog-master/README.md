# Fastapi_blog

Just a simple blog in fast api to understand and learn more about creating apis with fast api

# IN this project i was trying to create a simple blog api end points using Fast api

# To use this project

# create a python virtual env

To create a python virtual env use
`virtualenv venv`

after the creating the virtual env 
you need activate the virtual env 
by runninh simple command line

`source venv/bin/activate `

after activating the virtual env
# you need to install the dependencies by running

`pip install -r requirements.txt` 

this will install the dependencies

# run the app project
To run the application 
type 
`uvicorn blog.main:app --reload` 

this will fire up the application 
