from .settings import *

DATABASES['default']['NAME'] = 'robotframework'
